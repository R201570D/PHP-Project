	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> Mirrorless Cameras</a>
<ul>
<li><a href="mirrorless.php">Add DATA</a></li>
<li><a href="mirrorlesspoint.php">Confi</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Bridge Cameras</a>
					<ul>
						<li><a href="bridge.php">Add data</a></li>
						<li><a href="bridgepoint.php">config</a></li>
					</ul>
				</li>
				
				<li><a href="#"><i class="fa fa-sitemap"></i> DSLR Cameras</a>
					<ul>
						<li><a href="dslr.php">Add  data</a></li>
						<li><a href="dslrpoint.php">config</a></li>
					</ul>
				</li>
				
			</ul>
		</nav>